<?php

$username		= $_POST['username'];
$password		= $_POST['password'];
date_default_timezone_set("Asia/Jakarta");
$tglsekarang = date("Y-m-d H:i:s",time());
$log = $tglsekarang; 

include 'koneksi.php';
$query = mysqli_query($koneksi,"SELECT*FROM user WHERE username='$username' AND password='$password'");
if(mysqli_num_rows($query)==0){ ?>
		<script>
			alert("username Dan Nama Lengkap Tidak Ditemukan");
			window.location.assign("index.php")
		</script>
	<?php 
}else{
	$data = mysqli_fetch_assoc($query); 
	$id_user = $data['id_user'];

	if ($data['level']=="admin") {
		# code...
		session_start();
		$sql = "UPDATE user SET log='$log' WHERE id_user='$id_user'";
		$query = mysqli_query($koneksi, $sql);
        $_SESSION['username'] = $username;
        $_SESSION['password'] = $password;
        $_SESSION['level'] = $data['level'];
        header("location: Admin/main.php");

	} else if($data['level']=="waiter"){
		# code...
		session_start();
		$sql = "UPDATE user SET log='$log' WHERE id_user='$id_user'";
		$query = mysqli_query($koneksi, $sql);
		$_SESSION['username'] = $username;
        $_SESSION['password'] = $password;
        $_SESSION['level'] = $data['level'];
		header("location: waiter/main.php");
	
	} else if($data['level']=="kasir"){
		# code...
		session_start();
		$sql = "UPDATE user SET log='$log' WHERE id_user='$id_user'";
		$query = mysqli_query($koneksi, $sql);
		$_SESSION['username'] = $username;
        $_SESSION['password'] = $password;
        $_SESSION['level'] = $data['level'];
		header("location: Kasir/main.php");
	
	} else if($data['level']=="owner"){
		# code...
		session_start();
		$sql = "UPDATE user SET log='$log' WHERE id_user='$id_user'";
		$query = mysqli_query($koneksi, $sql);
		$_SESSION['username'] = $username;
        $_SESSION['password'] = $password;
        $_SESSION['level'] = $data['level'];
		header("location: owner/main.php");
	
	}else{
	
	}


	// session_start();
	// $_SESSION['username'] = $username;
	// $_SESSION['password'] = $password;
	// $_SESSION['level'] = $level;

	// header("Location:main.php");
}
<?php include('include/header.php') ?>
<div class="card">
	<div class="card-header">
		<a href="main.php" class="btn btn-success btn-icon-split">
       		 <span class="icon text-white-50">
            	 <i class="fas fa-arrow-left"></i>
             </span>
             <span class="text">Kembali</span>
        </a>
        <a href="printlog.php" class="btn btn-info btn-icon-split">
       		 <span class="icon text-white-50">
            	 <i class="fa fa-print"></i>
             </span>
             <span class="text">print</span>
        </a>
	</div>
	<div class="card-body">
        <div class="table-responsive">
             <form action="" method="get">
                 <div class="row mb-3">
                     <div class="col-md-9">
                         <input type="text" class="form-control" name="cari" value="<?= isset($_GET['cari']) == true ? $_GET['cari'] :''  ?>" placeholder="Cari">
                     </div>
                 </div>            
             </form>
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>password</th>
                        <th>level</th>
                        <th>log</th>
                    </tr>
                </thead>                 
                <?php
                    include 'koneksi.php';
                    $no = 1;
                    if(isset($_GET['cari']) && $_GET['cari'] != ''){
                        $cari = $_GET['cari'];
                        $sql = "SELECT * FROM user WHERE username LIKE '%$cari%'";
                    }else{
                        $sql = "SELECT * FROM user";
                    }
                    $result = mysqli_query($koneksi, $sql);
                    while($data = mysqli_fetch_array($result)){
                ?>
                <tbody>

          <tr>
              <td><?php echo $no++;?></td>
              <td><?php echo $data['username'];?></td>
              <td><?php echo $data['password'];?></td>
              <td><?php echo $data['level'];?></td>
              <td><?php echo $data['log']?></td>  
                </tr>
                <?php }?>
            </tbody>
            </table>
         </div>
	</div>
</div>
<?php include('include/footer.php') ?>
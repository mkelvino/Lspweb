<?php 

$id_transaksi = $_GET['id_transaksi'];

include'koneksi.php';
$sql = "DELETE FROM transaksi WHERE id_transaksi='$id_transaksi'";
$query = mysqli_query($koneksi, $sql);

if($query){ ?>
		<script>
			alert("Data transaksi Sudah Terhapus.");
			window.location.assign("transaksi.php");
		</script>
<?php 
 
}else{ ?>
		<script>
			alert("!!!Data transaksi Tidak Terhapus.");
			window.location.assign("transaksi.php");
		</script>
<?php 

}
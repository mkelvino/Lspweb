                 <nav class="navbar navbar-expand navbar-light pink topbar mb-4 static-top shadow">
                <h3 class="text-white"> <b> restaurant aplikasi </b></h3>
            </nav>
<?php include('include/header.php') ?>
<div class="card">
	<div class="card-header">
		<a href="main.php" class="btn btn-success btn-icon-split">
       		 <span class="icon text-white-50">
            	 <i class="fas fa-arrow-left"></i>
             </span>
             <span class="text">Kembali</span>
        </a>
	</div>
	<div class="card-body">
		<form method="post" action="simpan_table.php">
			<div class="form-group">
				<label>Nama meja</label>
				<input name="nama_table" class="form-control" type="text" placeholder="Masukan Nama Meja tersebut" required>
			</div>
			<div class="form-group">
				<label>Jumlah</label>
				<input name="jenis" class="form-control" type="jumlah" placeholder="Jumlah meja" required>
			</div>
			<div class="form-group">
				<label>status</label>
				<select name="status" class="form-select" aria-label="Default select example"> 
					<option selected hidden> status </option>	
					<option value="available">available</option>
					<option value="penuh">penuh</option>
				</select>
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-success"><i class="fa fa-save"></i>SIMPAN</button>
				<button type="reset" class="btn btn-danger"><i class="fa fa-trash"></i>KOSONGKAN</button>
			</div>
		</form>
	</div>
</div>
<?php include('include/footer.php') ?>
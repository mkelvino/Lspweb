<?php include('include/header.php') ?>
<div class="card">
	<div class="card-header">
		<a href="main.php" class="btn btn-success btn-icon-split">
       		 <span class="icon text-white-50">
            	 <i class="fas fa-arrow-left"></i>
             </span>
             <span class="text">Kembali</span>
        </a>
	</div>
	<div class="card-body">
		 <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama table</th>
                        <th>jumlah</th>
                        <th>status</th>
                       <th>Edit</th>
                       <th>Hapus</th>
                    </tr>
                </thead>                 
                <tbody>
                <?php
                    include 'koneksi.php';
                    $no = 1;
                    $sql = "SELECT * FROM meja";
                    $result = mysqli_query($koneksi, $sql);
                    while($data = mysqli_fetch_array($result)){
                ?>

          <tr>
              <td><?php echo $no++;?></td>
              <td><?php echo $data['nama_table'];?></td>
              <td><?php echo $data['jenis'];?></td>
              <td><?php echo $data['status'];?></td>
                    <td>
                        <a href="edit_table.php?id_table=<?= $data['id_table'] ?>"class="btn btn-success">
                            <i class="fa fa-pen"></i> Edit
                        </a>
                    </td>                          
                    <td>
                        <a onclick="return confirm('Apakah Anda Yakin Ingin Menghapus Data')"href="hapus_table.php?id_table=<?= $data['id_table'] ?>" class="btn btn-danger">
                            <i class="fa fa-trash"></i> Hapus
                        </a>    
                    </td>
                    <?php }?>      
                </tr>
            </tbody>
            </table>
         </div>
	</div>
</div>
<?php include('include/footer.php') ?>
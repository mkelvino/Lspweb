<?php 

session_start();
$username	  = $_POST['username'];
$password	  = $_POST['password'];
$level	  = $_POST['level'];

include'koneksi.php';
$sql = "INSERT INTO user(username,password,level) VALUES('$username','$password','$level')";
$query = mysqli_query($koneksi, $sql);

if($query){ ?>
		<script>
			alert("Data user Sudah Tersimpan.");
			window.location.assign("datauser.php");
		</script>
<?php 
 
}else{ ?>
		<script>
			alert("!!!Data user Tidak Tersimpan.");
			window.location.assign("datauser.php");
		</script>
<?php 

}
<?php 

$id_menu = $_GET['id_menu'];

include'koneksi.php';
$sql = "DELETE FROM menu WHERE id_menu='$id_menu'";
$query = mysqli_query($koneksi, $sql);

if($query){ ?>
		<script>
			alert("Data menu Sudah Terhapus.");
			window.location.assign("menu.php");
		</script>
<?php 
 
}else{ ?>
		<script>
			alert("!!!Data menu Tidak Terhapus.");
			window.location.assign("menu.php");
		</script>
<?php 

}
<?php 

$id_table = $_GET['id_table'];

include'koneksi.php';
$sql = "DELETE FROM meja WHERE id_table='$id_table'";
$query = mysqli_query($koneksi, $sql);

if($query){ ?>
		<script>
			alert("Data table Sudah Terhapus.");
			window.location.assign("datatable.php");
		</script>
<?php 
 
}else{ ?>
		<script>
			alert("Data table Tidak Terhapus.");
			window.location.assign("datatable.php");
		</script>
<?php 

}
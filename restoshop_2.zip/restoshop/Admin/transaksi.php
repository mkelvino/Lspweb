<?php include('include/header.php') ?>
<div class="card">
	<div class="card-header">
		<a href="transaksi.php" class="btn btn-success btn-icon-split">
       		 <span class="icon text-white-50">
            	 <i class="fas fa-arrow-left"></i>
             </span>
             <span class="text">Kembali</span>
        </a>
        <a href="printlogtransaksi.php" class="btn btn-info btn-icon-split">
       		 <span class="icon text-white-50">
            	 <i class="fa fa-print"></i>
             </span>
             <span class="text">Print</span>
        </a>
	</div>
	<div class="card-body">
		 <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                       <th>#</th>
                       <th>Tanggal Transaksi</th>
                       <th>Nama Menu</th>
                       <th>Jumlah</th>
                       <th>Total</th>
                       <th>Hapus</th>
                    </tr>
                </thead>                 
                <tbody>
                <?php
                    include 'koneksi.php';
                    $no = 1;
                    $sql = "SELECT transaksi.*, menu.nama_menu FROM transaksi INNER JOIN menu ON transaksi.id_menu = menu.id_menu";
                    $result = mysqli_query($koneksi, $sql);
                    while($data = mysqli_fetch_array($result)){
                ?>
          <tr>
          <td><?php echo $no++;?></td>
              <td><?php echo $data['tgl'];?></td>
              <td><?php echo $data['nama_menu'];?></td>
              <td><?php echo $data['jumlah'];?></td>
              <td><?php echo $data['total'];?></td>                          
                <td>
                    <a onclick="return confirm('Apakah Anda Yakin Ingin Menghapus Data')"href="hapus_transaksi.php?id_transaksi=<?= $data['id_transaksi'] ?>" class="btn btn-danger">
                        <i class="fa fa-trash "></i><span>delete</span>
                    </a>    
                </td>      
            </tr>
            <?php }?>
            </tbody>
            </table>
         </div>
	</div>
</div>
<?php include('include/footer.php') ?>
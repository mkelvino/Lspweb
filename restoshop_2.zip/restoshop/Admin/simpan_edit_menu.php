<?php 

$id_menu = $_POST['id_menu'];
$nama_menu  = $_POST['nama_menu'];
$jenis	  = $_POST['jenis'];
$harga	  = $_POST['harga'];

include'koneksi.php';
$sql = "UPDATE menu SET nama_menu='$nama_menu',jenis='$jenis',harga='$harga'WHERE id_menu='$id_menu'";
$query = mysqli_query($koneksi, $sql);

if($query){ ?>
		<script>
			alert("Data menu Sudah Teredit.");
			window.location.assign("menu.php");
		</script>
<?php 
 
}else{ ?>
		<script>
			alert("!!!Data menu Tidak Teredit.");
			window.location.assign("menu.php");
		</script>
<?php 

}
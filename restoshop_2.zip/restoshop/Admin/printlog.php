<?php 
session_start();
if(empty($_SESSION['password'])){ ?>
    <script>
        alert(' Maaf Anda Harus Login Dulu.. ')
        window.location.assign('../index.php');  
    </script>
<?php 
} 
include 'koneksi.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk</title>
</head>
<body>
    <script>window.print();</script>
    <div class="container">
        <div class="row">
            <div class="col-sm-4"></div>
            <div class="col-sm-4">
                <center>
                    <p>Tanggal : <?php  echo date("Y-m-d",time());?></p>
                </center>
                <table class="table table-bordered" style="width:100%;">
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>password</th>
                        <th>level</th>
                        <th>log</th>
					</tr>
                    <?php 
                        include 'koneksi.php';
                        $no = 1;
                        $sql = "SELECT * FROM user";
                        $result = mysqli_query($koneksi, $sql);
                        while($data = mysqli_fetch_array($result)){
                            # code...
                    ?>
                    <tr>
                        <td><?php echo $no++;?></td>
                        <td><?php echo $data['username'];?></td>
                        <td><?php echo $data['password'];?></td>
                        <td><?php echo $data['level'];?></td>
                        <td><?php echo $data['log']?></td> 
                    </tr>
                    <?php
                        $no++;}
                    ?>
                </table>
                <div class="clearfix">
					<center>
						<p>Laporan log pegawai</p>
					</center>
				</div>
            </div>
        </div>
    </div>
</body>
</html>
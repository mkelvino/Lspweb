<?php include('include/header.php') ?>
<div class="card">
	<div class="card-header">
		<a href="main.php" class="btn btn-success btn-icon-split">
       		 <span class="icon text-white-50">
            	 <i class="fas fa-arrow-left"></i>
             </span>
             <span class="text">Kembali</span>
        </a>
	</div>
	<div class="card-body">
		<form method="post" action="simpan_user.php">
			<div class="form-group">
				<label>Username</label>
				<input type="text" name="username" class="form-control" placeholder="Masukan Username" required>
			</div>
			<div class="form-group">
				<label>Password</label>
				<input type="text" name="password" class="form-control" placeholder="Masukan Password" required>
			</div>
			<div class="form-group">
				<label>Level</label>
				<select name="level" class="form-select" aria-label="Default select example"> 
					<option selected hidden> Pilihlah </option>	
					<option value="admin">admin</option>
					<option value="waiter">waiter</option>
					<option value="kasir">kasir</option>
					<option value="owner">owner</option>
				</select>
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-success"><i class="fa fa-save"></i>SIMPAN</button>
				<button type="reset" class="btn btn-danger"><i class="fa fa-trash"></i>KOSONGKAN</button>
			</div>
		</form>
	</div>
</div>
<?php include('include/footer.php') ?>
<?php 

$id_user = $_POST['id_user'];
$username  = $_POST['username'];
$password	  = $_POST['password'];
$level	  = $_POST['level'];

include'koneksi.php';
$sql = "UPDATE user SET username='$username',password='$password',level='$level' WHERE id_user='$id_user'";
$query = mysqli_query($koneksi, $sql);

if($query){ ?>
		<script>
			alert("Data User Sudah Teredit.");
			window.location.assign("datauser.php");
		</script>
<?php 
 
}else{ ?>
		<script>
			alert("!!!Data User Tidak Teredit.");
			window.location.assign("datauser.php");
		</script>
<?php 

}
<?php include('include/header.php') ?>
<?php
$id_menu = $_GET['id_menu'];
include 'koneksi.php';
$sql = "SELECT*FROM menu WHERE id_menu = '$id_menu'";
$query = mysqli_query($koneksi, $sql);
$value = mysqli_fetch_array($query);
?>

<div class="card">
	<div class="card-header">
		<a href="main.php" class="btn btn-success btn-icon-split">
       		 <span class="icon text-white-50">
            	 <i class="fas fa-arrow-left"></i>
             </span>
             <span class="text">Kembali</span>
        </a>
	</div>
	<div class="card-body">
		<form method="POST" action="simpan_edit_menu.php">
		<input type="hidden" name="id_menu" value="<?= $id_menu ?>">
			<div class="form-group">
				<label>ID Menu</label>
				<input value="<?= $value['id_menu'] ?>" name="id_menu" class="form-control" type="text" readonly>
			</div>
			<div class="form-group">
				<label>Nama Menu</label>
				<input value="<?= $value['nama_menu'] ?>" name="nama_menu" class="form-control" type="text" required>
			</div>
			<div class="form-group">
				<label>Jenis Menu</label>
				<input value="<?= $value['jenis'] ?>" name="jenis" class="form-control" type="text"  required>
			</div>
			<div class="form-group">
				<label>Harga</label>
				<input value="<?= $value['harga'] ?>" name="harga" class="form-control" type="text" required>
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-success"><i class="fa fa-save"></i>SIMPAN</button>
			</div>
		</form>
	</div>
</div>
<?php include('include/footer.php') ?>
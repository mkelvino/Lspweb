<?php include('include/header.php') ?>
<?php

$id_user = $_GET['id_user'];
include 'koneksi.php';
$sql = "SELECT*FROM user WHERE id_user = '$id_user'";
$query = mysqli_query($koneksi, $sql);
$value = mysqli_fetch_array($query);
?>

<div class="card">
	<div class="card-header">
		<a href="main.php" class="btn btn-success btn-icon-split">
       		 <span class="icon text-white-50">
            	 <i class="fas fa-arrow-left"></i>
             </span>
             <span class="text">Kembali</span>
        </a>
	</div>
	<div class="card-body">
		<form method="POST" action="simpan_edit_user.php">
		<input type="hidden" name="id_user" value="<?= $id_user ?>">
			<div class="form-group">
				<label>ID Menu</label>
				<input value="<?= $value['id_user'] ?>" name="id_user" class="form-control" type="text" readonly>
			</div>
			<div class="form-group">
				<label>Nama Menu</label>
				<input value="<?= $value['username'] ?>" name="username" class="form-control" type="text" required>
			</div>
			<div class="form-group">
				<label>password Menu</label>
				<input value="<?= $value['password'] ?>" name="password" class="form-control" type="text"  required>
			</div>
			<div class="form-group">
				<label>level</label>
				<select name="level" class="form-select" aria-label="Default select example"> 
					<option selected hidden> pilihlah </option>	
				 	<option value="admin">admin</option>
					<option value="waiter">waiter</option>
					<option value="kasir">kasir</option>
					<option value="owner">owner</option>
				</select>
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-success"><i class="fa fa-save"></i>SIMPAN</button>
			</div>
		</form>
	</div>
</div>
<?php include('include/footer.php') ?>
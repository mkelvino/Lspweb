<?php 

session_start();
$nama_menu	  = $_POST['nama_menu'];
$jenis	  = $_POST['jenis'];
$harga	  = $_POST['harga'];

include'koneksi.php';
$sql = "INSERT INTO menu(nama_menu,jenis,harga) VALUES('$nama_menu','$jenis','$harga')";
$query = mysqli_query($koneksi, $sql);

if($query){ ?>
		<script>
			alert("Data menu Sudah Tersimpan.");
			window.location.assign("menu.php");
		</script>
<?php 
 
}else{ ?>
		<script>
			alert("!!!Data menu Tidak Tersimpan.");
			window.location.assign("menu.php");
		</script>
<?php 

}
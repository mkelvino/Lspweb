<?php 

$id_table = $_POST['id_table'];
$nama_table  = $_POST['nama_table'];
$jenis	  = $_POST['jenis'];
$status	  = $_POST['status'];

include'koneksi.php';
$sql = "UPDATE meja SET nama_table='$nama_table',jenis='$jenis',status='$status' WHERE id_table='$id_table'";
$query = mysqli_query($koneksi, $sql);

if($query){ ?>
		<script>
			alert("Data table Sudah Teredit.");
			window.location.assign("datatable.php");
		</script>
<?php 
 
}else{ ?>
		<script>
			alert("Data table Tidak Teredit.");
			window.location.assign("datatable.php");
		</script>
<?php 

}
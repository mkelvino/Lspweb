<?php include('include/header.php') ?>
<div class="card">
	<div class="card-header">
		<a href="main.php" class="btn btn-success btn-icon-split">
       		 <span class="icon text-white-50">
            	 <i class="fas fa-arrow-left"></i>
             </span>
             <span class="text">Kembali</span>
        </a>
	</div>
	<div class="card-body">
		<form method="post" action="simpan_menu.php">
			<div class="form-group">
				<label>Nama Menu</label>
				<input name="nama_menu" class="form-control" type="text" placeholder="Masukan Nama Menu" required>
			</div>
			<div class="form-group">
				<label>Jenis</label>
				<input name="jenis" class="form-control" type="text" placeholder="Jenis Menu" required>
			</div>
			<div class="form-group">
				<label>Harga</label>
				Rp. <input name="harga" class="form-control" type="number"  required>
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-success"><i class="fa fa-save"></i>SIMPAN</button>
				<button type="reset" class="btn btn-danger"><i class="fa fa-trash"></i>KOSONGKAN</button>
			</div>
		</form>
	</div>
</div>
<?php include('include/footer.php') ?>
<?php include('include/header.php') ?>
<?php
$id_table = $_GET['id_table'];
include 'koneksi.php';
$sql = "SELECT*FROM meja WHERE id_table = '$id_table'";
$query = mysqli_query($koneksi, $sql);
$value = mysqli_fetch_array($query);
?>

<div class="card">
    <div class="card-header">
        <a href="main.php" class="btn btn-success btn-icon-split">
                <span class="icon text-white-50">
                 <i class="fas fa-arrow-left"></i>
             </span>
             <span class="text">Kembali</span>
        </a>
    </div>
    <div class="card-body">
        <form method="POST" action="simpan_edit_table.php">
        <input type="hidden" name="id_table" value="<?= $id_table ?>">
            <div class="form-group">
                <label>Nama Table</label>
                <input value="<?= $value['nama_table'] ?>" name="nama_table" class="form-control" type="text" readonly>
            </div>
            <div class="form-group">
                <label>Jenis</label>
                <input value="<?= $value['jenis'] ?>" name="jenis" class="form-control" type="text" required>
            </div>
			<div class="form-group">
				<label>status</label>
				<select value="<?= $value['status'] ?>" name="status" class="form-select" aria-label="Default select example"> 
					<option selected hidden> pilihlah </option>	
				 	<option value="available">available</option>
					<option value="penuh">penuh</option>
				</select>
			</div>
            <div class="form-group">
                <button type="submit" class="btn btn-success"><i class="fa fa-save"></i>SIMPAN</button>
            </div>
        </form>
    </div>
</div>
<?php include('include/footer.php') ?>
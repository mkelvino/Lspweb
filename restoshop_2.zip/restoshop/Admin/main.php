<?php include('include/header.php') ?>
<?php
echo "<h1><p align=center><b>Selamat Datang Di restaurant aplikasi.</b></p></h1><br>";
echo "<h1><p align=center><b>".$_SESSION['username']."</b></p></h1>";  
?>
<?php include('include/footer.php') ?>
<?php 

session_start();
$nama_table	  = $_POST['nama_table'];
$jenis	  = $_POST['jenis'];
$status	  = $_POST['status'];

include'koneksi.php';
$sql = "INSERT INTO meja(nama_table,jenis,status) VALUES('$nama_table','$jenis','$status')";
$query = mysqli_query($koneksi, $sql);

if($query){ ?>
		<script>
			alert("Data meja Sudah Tersimpan.");
			window.location.assign("datatable.php");
		</script>
<?php 
 
}else{ ?>
		<script>
			alert("Data meja Tidak Tersimpan.");
			window.location.assign("datatable.php");
		</script>
<?php 

}
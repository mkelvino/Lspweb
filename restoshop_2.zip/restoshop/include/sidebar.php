<ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center">
                <div class="sidebar-brand-icon rotate-n-15">
                </div>
                <div class="sidebar-brand-text mx-3"> restaurant</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">



            <!-- Nav Item - Dashboard -->
            

            <li class="nav-item">
                <a class="nav-link" href="main.php">
                    <i class="fas fa-fw fa-user"></i>
                    <span>User</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Interface
            </div>
            
            </li>

            <li class="nav-item">
                <a class="nav-link" href="tambah_menu.php">
                    <i class="fas fa-fw fa-pen"></i>
                    <span>Tambah Menu </span></a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link" href="tambah_user.php">
                    <i class="fas fa-fw fa-pen"></i>
                    <span>Tambah User </span></a>
            </li>

            <!-- Nav Item - Tables -->
            <li class="nav-item">
                <a class="nav-link" href="menu.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Barang </span></a>
            </li>


            <li class="nav-item">
                <a class="nav-link" href="datauser.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>User </span></a>
            </li>


            <li class="nav-item">
                <a class="nav-link" href="transaksi.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Transaksi </span></a>
            </li>

             <!-- Nav Item - Tables -->
             <li class="nav-item">
                <a class="nav-link" href="kasir.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>kasir </span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="loguser.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Log User </span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-fw fa-power-off"></i>
                    <span>Logout</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->

        </ul>
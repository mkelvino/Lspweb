<?php

$username	=$_POST['username'];
$password	=$_POST['password'];
$level 	= 'kasir';

include'koneksi.php';
$query_validasi = "SELECT*FROM user WHERE username='$username' ";
$query = mysqli_query($koneksi, $query_validasi);

if(mysqli_num_rows($query)==0){
	$query_register = mysqli_query($koneksi, "INSERT INTO user(username,password,level) VALUES('$username','$password','$level')");
	if($query_register){ ?>
		<script>
			alert("Data Register Sudah Berhasil Dilakukan, Silahkan Login!");
			window.location.assign("index.php");
		</script>
	<?php }
}else{ ?>
		<script>
			alert("Username Yang Anda Gunakan Sudah Terdaftar");
			window.location.assign("register.php")
		</script>
	<?php 
  }

<?php include('include/header.php') ?>
<?php
include 'koneksi.php';

$bayar = '';
$hitung = '';
$total_bayar = '';
?>
<div class="card">
	<div class="card-header">
		<a href="main.php" class="btn btn-success btn-icon-split float-left">
       		 <span class="icon text-white-50">
            	 <i class="fas fa-arrow-left"></i>
             </span>
             <span class="text">Kembali</span>
        </a>
	</div>
</div>
<div class="row">
    <div class="col-sm-4">
        <div class="card card-primary mb-3">
            <div class="card-header bg-info text-white mb-2">
                <h5><i class="fa fa-search"></i> Cari Barang</h5>
            </div>
            <div class="card-body">
                <form action="" method="get">
                    <div class="row">
                        <div class="col-md-9">
                            <input type="text" class="form-control" name="cari" value="<?= isset($_GET['cari']) == true ? $_GET['cari'] :''  ?>" placeholder="Masukan : Kode / Nama Barang">
                        </div>
                    </div>            
                </form>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="card card-primary mb-3">
            <div class="card-header bg-info text-white">
                <h5><i class="fa fa-list"></i> Hasil Pencarian</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <?php
                        $no    = 1;
                        if(isset($_GET['cari']) && $_GET['cari'] != ''){
                            $cari = $_GET['cari'];
                            $sql   = "SELECT*FROM pesanan WHERE kode LIKE '%$cari%'";
                        
                        $query = mysqli_query($koneksi, $sql);
                        if ($query) {
                            if(mysqli_num_rows($query) > 0){
                    ?>
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode Pesanan</th>
                            </tr>
                        </thead>                 
                        <tbody>
                            <?php
                                foreach ($query as $value) {
                            ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= $value['kode'] ?></td>
                                <td>
                                    <a href="kasir.php?idpesanan=<?= $value['kode']; ?>"class="btn btn-success">
                                        <i class="fas fa-shopping-cart"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php }?>
                        </tbody>
                    </table>
                    <?php        
                            }else {
                                echo "<center><h3>Tidak ada data</h3></center>";                       
                            }
                        }else{
                            echo "<center><h3>Telah Terjadi Kesalahan</h3></center>";
                        }
                    }else {
                        $sql   = "SELECT*FROM pesanan";
                    
                    $query = mysqli_query($koneksi, $sql);
                    if ($query) {
                        if(mysqli_num_rows($query) > 0){
                    ?>
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode Pesanan</th>
                            </tr>
                        </thead>                 
                        <tbody>
                            <?php
                                foreach ($query as $value) {
                            ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= $value['kode'] ?></td>
                                <td>
                                    <a href="kasir.php?kode=<?= $value['kode']; ?>"class="btn btn-success">
                                        <i class="fas fa-shopping-cart"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php }?>
                        </tbody>
                    </table>
                    <?php        
                            }else {
                                echo "<center><h3>Tidak ada data</h3></center>";                       
                            }
                        }else{
                            echo "<center><h3>Telah Terjadi Kesalahan</h3></center>";
                        }
                    } ?>
                </div>
            </div>         
        </div>
    </div>

    <?php
    if (isset($_GET['kode']) && $_GET['kode'] != '') {
        # code...
        $kode = $_GET['kode'];
        $sqlquery =  mysqli_query($koneksi,"SELECT*FROM pesanan WHERE kode = '$kode'");
        if(mysqli_num_rows($sqlquery)==0){ ?>
            <script>
                alert("Data Sudah di Input");
            </script>
        <?php 
        }else{
        $data = mysqli_fetch_array($sqlquery);
        $id_pesanan = $data['id_pesanan'];
        $idmenu = $data['id_menu'];
        $idpelanggan = $data['id_pelanggan'];
        $tgl = $data['tgl'];
        $jumlah = $data['jumlah'];
        $total = $data['total'];
        $jumlah_dipilih = count($kode);
        for($x=0;$x<$jumlah_dipilih;$x++){
            $sql2 = "INSERT INTO bayar(id_menu,id_pelanggan,kode,tgl,jumlah,total) VALUES('$idmenu','$idpelanggan','$kode','$tgl','$jumlah','$total')";
            $query = mysqli_query($koneksi, $sql2);
        }
        }
    }
    ?>
    <?php
        if (isset($_GET['hapus'])&& $_GET['hapus'] == 'pesan') {
            # code...
            $sqlhapus = "DELETE FROM pesan";
            $query5 = mysqli_query($koneksi, $sqlhapus);
        }
    ?>
    <div class="col-sm-12">
        <div class="card card-primary">
            <div class="card-header bg-info text-white">
                <h5><i class="fa fa-shopping-cart"></i>Kasir
                <a class="btn btn-danger float-right" onclick="javascript:return confirm('Apakah anda ingin reset keranjang ?');" href="kasir.php?hapus=pesan">
					<b>RESET KERANJANG</b>
                </a>       
            </h5>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <?php
                    if (isset($_GET['hapusid'])&& $_GET['hapusid'] != '') {
                    # code...
                    $idbayar1 = $_GET['hapusid'];
                    $sqlhapus2 = "DELETE FROM bayar WHERE id_bayar = '$idbayar1'";
                    $query6 = mysqli_query($koneksi, $sqlhapus2);
                    }
                ?>
                <?php
                    $sql3   = "SELECT bayar.*, pelanggan.id_pelanggan, pelanggan.nama_pelanggan, menu.id_menu, menu.nama_menu FROM bayar INNER JOIN menu ON bayar.id_menu = menu.id_menu INNER JOIN pelanggan ON bayar.id_pelanggan = pelanggan.id_pelanggan";
                        
                    $query2 = mysqli_query($koneksi, $sql3);
                    if ($query2) {
                        if(mysqli_num_rows($query2) > 0){
                ?>
                <table class="table table-bordered w-100">
                    <thead>
                        <tr>
                            <td>No</td>
                            <td>Nama Menu</td>
                            <td>Nama Pelanggan</td>
                            <td>Kode</td>
                            <td>Tanggal</td>
                            <td>Jumlah</td>
                            <td>Total</td>
                            <td>Aksi</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $total_bayar = 0;
                            foreach ($query2 as $data1) {
                        ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $data1['nama_menu'] ?></td>
                            <td><?= $data1['nama_pelanggan'] ?></td>
                            <td><?php echo $data1['kode'];?></td>
                            <td><?php echo $data1['tgl'];?></td>
                            <td>
                                        <input type="number" name="jumlah" value="<?php echo $data1['jumlah'];?>" class="form-control" readonly>
								    	<input type="hidden" name="id_bayar" value="<?php echo $data1['id_bayar'];?>" class="form-control">
								    	<input type="hidden" name="id_menu" value="<?php echo $data1['id_menu'];?>" class="form-control">
								    	<input type="hidden" name="id_pelanggan" value="<?php echo $data1['id_pelanggan'];?>" class="form-control">
                                    </td>
                                    <td>Rp.<?php echo $data1['total'];?><td>
                                <a href="kasir.php?hapusid=<?php echo $data1['id_bayar'];?>" class="btn btn-danger"><i class="fa fa-times"></i>
								</a>
                            </td>
                        </tr>
                        <?php $total_bayar += $data1['total']; }?>
                    </tbody>
                </table>
                <?php        
                        }else {
                            $total_bayar = 0;
                            echo "<center><h3>Tidak ada data</h3></center>";                       
                        }
                    }else{
                        $total_bayar = 0;
                        echo "<center><h3>Telah Terjadi Kesalahan</h3></center>";
                    }
                ?>
                <br>
                <div id="kasirnya">
                    <table class="table table-stripped">
                        <?php
                            if (isset($_GET['struk']) && $_GET['struk'] == 'ya') {
                                # code...
                                $total = $_POST['total'];
								$bayar = $_POST['bayar'];
                                if(!empty($bayar)){
                                    $hitung = $bayar - $total;
                                    if ($bayar >= $total) {
                                        # code...
										$id_menu = $_POST['id_menu8'];
                                        $tgl = $_POST['struk1'];
										$jumlah = $_POST['jumlah8'];
										$total = $_POST['total8'];
                                        $jumlah_dipilih = count($id_menu);
                                        for($x=0;$x<$jumlah_dipilih;$x++){
                                            $sql8 = "INSERT INTO transaksi (id_menu,tgl,jumlah,total) VALUES('$id_menu[$x]','$tgl[$x]','$jumlah[$x]','$total[$x]')";
                                            $query8 = mysqli_query($koneksi, $sql8);
                                        }
                                        echo '<script>alert("Belanjaan Berhasil Di Bayar !");</script>';
                                    } else {
                                        # code...
                                        echo '<script>alert("Uang Kurang ! Rp.'.$hitung.'");</script>';
                                    }
                                    
                                }
                            }
                        ?>
                        <?php 
                            date_default_timezone_set("Asia/Jakarta");
                            $tglsekarang = date("Y-m-d",time());
                            $tgl = $tglsekarang;
                        ?>
                        <form action="kasir.php?struk=ya" method="post">
                            <?php $no1=0; foreach ($query2 as $data1){ ?>
                                <input type="hidden" name="struk1[]" value="<?php echo $tgl;?>" readonly>
								<input type="hidden" name="id_menu8[]" value="<?php echo $data1['id_menu'];?>">
								<input type="hidden" name="jumlah8[]" value="<?php echo $data1['jumlah'];?>">
								<input type="hidden" name="total8[]" value="<?php echo $data1['total'];?>">
                            <?php $no1++; } ?>
                            <tr>
                                <td>Tanggal Transaksi</td>
                                <td><input type="text" value="<?php echo $tgl;?>" readonly></td>
                            </tr>
                            <tr>
									<td>Total Semua  </td>
									<td><input type="text" class="form-control" name="total" value="<?php echo $total_bayar;?>" readonly></td>
									<td>Bayar  </td>
									<td><input type="text" class="form-control" name="bayar" value="<?php echo $bayar;?>"></td>
									<td><button class="btn btn-success"><i class="fa fa-shopping-cart"></i> Bayar</button>
									<?php  if(isset($_GET['struk']) && $_GET['struk'] == 'ya') {?>
										<a class="btn btn-danger" href="kasir.php?hapus=pesan">
										<b>RESET</b></a></td><?php }?></td>
								</tr>
                        </form>
                        <tr>
                            <td>Kembalian</td>
                            <td><input type="text" class="form-control" value="<?php echo $hitung;?>" readonly></td>
                            <td></td>
                            <td>
                                <a href="printstruk.php?total=<?php echo $total_bayar;?>&bayar=<?php echo $bayar;?>&kembali=<?php echo $hitung; ?>">
                                    <button class="btn btn-info">
                                        <i class="fa fa-print"></i> Print pembayaran
                                    </button>
                                </a>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('include/footer.php') ?>
<?php 
session_start();
if(empty($_SESSION['password'])){ ?>
    <script>
        alert(' Maaf Anda Harus Login Dulu.. ')
        window.location.assign('index.php');  
    </script>
<?php 
} 
include 'koneksi.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk</title>
</head>
<body>
    <script>window.print();</script>
    <div class="container">
        <div class="row">
            <div class="col-sm-4"></div>
            <div class="col-sm-4">
                <center>
                    <p>Tanggal : <?php  echo date("Y-m-d",time());?></p>
                </center>
                <table class="table table-bordered" style="width:100%;">
                    <tr>
						<td>No.</td>
						<td>Barang</td>
						<td>Jumlah</td>
						<td>Total</td>
					</tr>
                    <?php 
                        $sql = "SELECT pesan.*, menu.id_menu, menu.nama_menu FROM pesan INNER JOIN menu ON pesan.id_menu = menu.id_menu";
                        $query = mysqli_query($koneksi, $sql);
                        $no = 1;
                        foreach ($query as $value) {
                            # code...
                    ?>
                    <tr>
                        <td><?php echo $no;?></td>
                        <td><?php echo $value['nama_menu'];?></td>
                        <td><?php echo $value['jumlah'];?></td>
                        <td><?php echo $value['total'];?></td>
                    </tr>
                    <?php
                        $no++;}
                    ?>
                </table>
                <div class="pull-right">
						Total : Rp.<?php echo $_GET['total'];?>,-
						<br/>
						Bayar : Rp.<?php echo htmlentities($_GET['bayar']);?>,-
						<br/>
						Kembali : Rp.<?php echo htmlentities($_GET['kembali']);?>,-
				</div>
                <div class="clearfix">
					<center>
						<p>Terima Kasih Telah berbelanja!</p>
					</center>
				</div>
            </div>
        </div>
    </div>
</body>
</html>
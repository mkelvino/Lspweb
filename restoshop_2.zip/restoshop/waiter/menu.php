<?php include('include/header.php') ?>
<div class="card">
	<div class="card-header">
		<a href="main.php" class="btn btn-success btn-icon-split">
       		 <span class="icon text-white-50">
            	 <i class="fas fa-arrow-left"></i>
             </span>
             <span class="text">Kembali</span>
        </a>
	</div>
	<div class="card-body">
		 <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                       <th>No</th>
                       <th>Nama Menu</th>
                       <th>Jenis</th>
                       <th>Harga</th>
                       <th>Edit</th>
                       <th>Hapus</th>
                    </tr>
                </thead>                 
                <tbody>
                	<?php
                	$no    = 1;
                	include'koneksi.php';
                	$sql   = "SELECT*FROM menu";
                	$query =mysqli_query($koneksi, $sql);
                	foreach ($query as $value) {
                	?>
                    <tr>
              	        <td><?= $no++; ?></td>
                	    <td><?= $value['nama_menu'] ?></td>
                    	<td><?= $value['jenis'] ?></td>
                    	<td>Rp.<?= $value['harga'] ?></td>
                        <td>
                            <a href="edit_menu.php?id_menu=<?= $value['id_menu']; ?>"class="btn btn-success">
                                <i class="fa fa-pen"></i> Edit
                            </a>
                        </td>
                        <td>
                            <a onclick="return confirm('Apakah Anda Yakin Ingin Menghapus Data')"href="hapus_menu.php?id_menu=<?= $value['id_menu'] ?>" class="btn btn-danger">
                                <i class="fa fa-trash"></i> Hapus
                            </a>    
                        </td>
                    </tr>
                <?php } ?> 
                </tbody>
            </table>
         </div>
	</div>
</div>
<?php include('include/footer.php') ?>
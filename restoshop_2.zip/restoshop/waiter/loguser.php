<?php include('include/header.php') ?>
<div class="card">
	<div class="card-header">
		<a href="main.php" class="btn btn-success btn-icon-split">
       		 <span class="icon text-white-50">
            	 <i class="fas fa-arrow-left"></i>
             </span>
             <span class="text">Kembali</span>
        </a>
        <a href="printlog.php" class="btn btn-info btn-icon-split">
       		 <span class="icon text-white-50">
            	 <i class="fa fa-print"></i>
             </span>
             <span class="text">print</span>
        </a>
	</div>
	<div class="card-body">
		 <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>password</th>
                        <th>level</th>
                        <th>log</th>
                    </tr>
                </thead>                 
                <tbody>
                <?php
                    include 'koneksi.php';
                    $no = 1;
                    $sql = "SELECT * FROM user";
                    $result = mysqli_query($koneksi, $sql);
                    while($data = mysqli_fetch_array($result)){
                ?>

          <tr>
              <td><?php echo $no++;?></td>
              <td><?php echo $data['username'];?></td>
              <td><?php echo $data['password'];?></td>
              <td><?php echo $data['level'];?></td>
              <td><?php echo $data['log']?></td>  
                </tr>
                <?php }?>
            </tbody>
            </table>
         </div>
	</div>
</div>
<?php include('include/footer.php') ?>
<?php include('include/header.php') ?>
<?php
include 'koneksi.php';

$bayar = '';
$hitung = '';
$total_bayar = '';
?>
<div class="card">
	<div class="card-header">
		<a href="main.php" class="btn btn-success btn-icon-split float-left">
       		 <span class="icon text-white-50">
            	 <i class="fas fa-arrow-left"></i>
             </span>
             <span class="text">Kembali</span>
        </a>
	</div>
</div>
<div class="row">
    <div class="col-sm-4">
        <div class="card card-primary mb-3">
            <div class="card-header bg-info text-white mb-2">
                <h5><i class="fa fa-search"></i> Cari Barang</h5>
            </div>
            <div class="card-body">
                <form action="" method="get">
                    <div class="row">
                        <div class="col-md-9">
                            <input type="text" class="form-control" name="cari" value="<?= isset($_GET['cari']) == true ? $_GET['cari'] :''  ?>" placeholder="Masukan : Kode / Nama Barang" required>
                        </div>
                    </div>            
                </form>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="card card-primary mb-3">
            <div class="card-header bg-info text-white">
                <h5><i class="fa fa-list"></i> Hasil Pencarian</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <?php
                        $no    = 1;
                        if(isset($_GET['cari']) && $_GET['cari'] != ''){
                            $cari = $_GET['cari'];
                            $sql   = "SELECT*FROM menu WHERE id_menu LIKE '%$cari%' OR nama_menu LIKE '%$cari%' OR jenis LIKE '%$cari%'";
                        
                        $query = mysqli_query($koneksi, $sql);
                        if ($query) {
                            if(mysqli_num_rows($query) > 0){
                    ?>
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Menu</th>
                                <th>Jenis</th>
                                <th>Harga</th>
                                <th>Edit</th>
                            </tr>
                        </thead>                 
                        <tbody>
                            <?php
                                foreach ($query as $value) {
                            ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= $value['nama_menu'] ?></td>
                                <td><?= $value['jenis'] ?></td>
                                <td>Rp.<?= $value['harga'] ?></td>
                                <td>
                                    <a href="order.php?idmenu=<?= $value['id_menu']; ?>"class="btn btn-success">
                                        <i class="fas fa-shopping-cart"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php }?>
                        </tbody>
                    </table>
                    <?php        
                            }else {
                                echo "<center><h3>Tidak ada data</h3></center>";                       
                            }
                        }else{
                            echo "<center><h3>Telah Terjadi Kesalahan</h3></center>";
                        }
                    }else {
                    ?>
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0"></table>
                    <?php } ?>
                </div>
            </div>         
        </div>
    </div>

    <?php
    if (isset($_GET['idmenu']) && $_GET['idmenu'] != '') {
        # code...
        $idmenu = $_GET['idmenu'];
        $sqlquery =  mysqli_query($koneksi,"SELECT*FROM pesan WHERE id_menu = '$idmenu'");
        if(mysqli_num_rows($sqlquery)!=0){ ?>
            <script>
                alert("Data Sudah di Input");
            </script>
        <?php 
        }else{
        $sql1 = "SELECT*FROM menu WHERE id_menu = '$idmenu'";
        $query1 = mysqli_query($koneksi, $sql1);
        $data = mysqli_fetch_array($query1);
        $idmenu = $data['id_menu'];
        $jumlah = 1;
        $total = $data['harga'];
        $sql2 = "INSERT INTO pesan(id_menu,jumlah,total) VALUES('$idmenu','$jumlah','$total')";
        $query = mysqli_query($koneksi, $sql2);
        }
    }
    ?>
    <?php
        if (isset($_GET['hapus'])&& $_GET['hapus'] == 'pesan') {
            # code...
            $sqlhapus = "DELETE FROM pesan";
            $query5 = mysqli_query($koneksi, $sqlhapus);
        }
    ?>
    <div class="col-sm-12">
        <div class="card card-primary">
            <div class="card-header bg-info text-white">
                <h5><i class="fa fa-shopping-cart"></i>order
                <a class="btn btn-danger float-right" onclick="javascript:return confirm('Apakah anda ingin reset keranjang ?');" href="order.php?hapus=pesan">
					<b>RESET KERANJANG</b>
                </a>       
            </h5>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <?php
                if (isset($_GET['id_pesan'])&& $_GET['id_pesan'] != '' &&
                isset($_GET['id_menu'])&& $_GET['id_menu'] != '' &&
                isset($_GET['jumlah'])&& $_GET['jumlah'] != ''
                ) {
                    # code...
                    $id_pesan = $_GET['id_pesan'];
                    $id_menu = $_GET['id_menu'];
                    $jumlah1 = $_GET['jumlah'];
                    $sql3 = "SELECT*FROM menu WHERE id_menu = '$id_menu'";
                    $query3 = mysqli_query($koneksi, $sql3);
                    $data3 = mysqli_fetch_array($query3);
                    $total2 = ($jumlah1 * $data3['harga']);
                    $sql4 = "UPDATE pesan SET id_pesan='$id_pesan',id_menu='$id_menu',jumlah='$jumlah1',total='$total2'WHERE id_menu='$id_menu'";
                    $query4 = mysqli_query($koneksi, $sql4);

                }
                ?>
                <?php
                    if (isset($_GET['hapusid'])&& $_GET['hapusid'] != '') {
                    # code...
                    $idpesan1 = $_GET['hapusid'];
                    $sqlhapus2 = "DELETE FROM pesan WHERE id_pesan = '$idpesan1'";
                    $query6 = mysqli_query($koneksi, $sqlhapus2);
                    }
                ?>
                <?php
                    $sql3   = "SELECT pesan.*, menu.id_menu, menu.nama_menu FROM pesan INNER JOIN menu ON pesan.id_menu = menu.id_menu";
                        
                    $query2 = mysqli_query($koneksi, $sql3);
                    if ($query2) {
                        if(mysqli_num_rows($query2) > 0){
                ?>
                <table class="table table-bordered w-100">
                    <thead>
                        <tr>
                            <td>No</td>
                            <td>Nama Menu</td>
                            <td>Jumlah</td>
                            <td>Total</td>
                            <td>Aksi</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $total_bayar = 0;
                            foreach ($query2 as $data1) {
                        ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $data1['nama_menu'] ?></td>
                            <td>
                                <form action="" method="get">
                                        <input type="number" name="jumlah" value="<?php echo $data1['jumlah'];?>" class="form-control">
								    	<input type="hidden" name="id_pesan" value="<?php echo $data1['id_pesan'];?>" class="form-control">
								    	<input type="hidden" name="id_menu" value="<?php echo $data1['id_menu'];?>" class="form-control">
                                    </td>
                                    <td>Rp.<?php echo $data1['total'];?>
                                    <td>
										<button type="submit" class="btn btn-warning">Update</button>
                                </form>
                                <a href="order.php?hapusid=<?php echo $data1['id_pesan'];?>" class="btn btn-danger"><i class="fa fa-times"></i>
								</a>
                            </td>
                        </tr>
                        <?php $total_bayar += $data1['total']; }?>
                    </tbody>
                </table>
                <?php        
                        }else {
                            $total_bayar = 0;
                            echo "<center><h3>Tidak ada data</h3></center>";                       
                        }
                    }else{
                        $total_bayar = 0;
                        echo "<center><h3>Telah Terjadi Kesalahan</h3></center>";
                    }
                ?>
                <br>
                <div id="ordernya">
                    <table class="table table-stripped">
                        <?php
                            if (isset($_GET['struk']) && $_GET['struk'] == 'ya') {
                                # code...
                                $total = $_POST['total'];

								$id_menu = $_POST['id_menu8'];
                                $pelanggan = $_POST['pelanggan'];
                                $kode = $_POST['kode'];
                                $tgl = $_POST['struk1'];
								$jumlah = $_POST['jumlah8'];
								$total = $_POST['total8'];
                                $jumlah_dipilih = count($id_menu);
                                for($x=0;$x<$jumlah_dipilih;$x++){
                                    $sql8 = "INSERT INTO pesanan (id_menu,id_pelanggan,kode,tgl,jumlah,total) VALUES('$id_menu[$x]','$pelanggan','$kode','$tgl[$x]','$jumlah[$x]','$total[$x]')";
                                    $query8 = mysqli_query($koneksi, $sql8);
                                }
                                echo '<script>alert("Belanjaan Berhasil Di Pesan !");</script>';
                                    
                                
                            }
                        ?>
                        <?php 
                            date_default_timezone_set("Asia/Jakarta");
                            $kodetgl = date("G.md.Y",time());
                            $tglsekarang = date("Y-m-d",time());
                            $tgl = $tglsekarang;
                            $kode = "K.".$kodetgl;
                        ?>
                        <form action="order.php?struk=ya" method="post">
                            <tr>
                                <div class="form-group">
                                    <td>pelanggan</td>
                                    <td><select name="pelanggan" class="form-select" aria-label="Default select example"> 
                                        <?php
                                            $sqlpelanggan = mysqli_query($koneksi,"SELECT * FROM pelanggan");
                                            while($data = mysqli_fetch_array($sqlpelanggan)){
                                        ?>
                                        <option value="<?php echo $data['id_pelanggan']?>"><?php echo $data['nama_pelanggan']?></option>
                                        <?php } ?>
                                    </select></td>
                                </div>
                            </tr>
                            <?php $no1=0; foreach ($query2 as $data1){ ?>
                                <input type="hidden" name="struk1[]" value="<?php echo $tgl;?>" readonly>
								<input type="hidden" name="id_menu8[]" value="<?php echo $data1['id_menu'];?>">
								<input type="hidden" name="jumlah8[]" value="<?php echo $data1['jumlah'];?>">
								<input type="hidden" name="total8[]" value="<?php echo $data1['total'];?>">
                            <?php $no1++; } ?>
                            <tr>
                                <td>Kode Transaksi</td>
                                <td><input type="text" name="kode" value="<?php echo $kode;?>" readonly></td>
                                <td>Tanggal Transaksi</td>
                                <td><input type="text" value="<?php echo $tgl;?>" readonly></td>
                            </tr>
                            <tr>
									<td>Total Semua  </td>
									<td><input type="text" class="form-control" name="total" value="<?php echo $total_bayar;?>" readonly></td>
                                    <td></td>
									<td><button class="btn btn-success"><i class="fa fa-shopping-cart"></i> Pesan</button>
										<a class="btn btn-danger" href="order.php?hapus=pesan">
										<b>RESET</b></a></td></td>
								</tr>
                        </form>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('include/footer.php') ?>